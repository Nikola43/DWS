<!DOCTYPE html>
<html lang="es">
<body>
<form method="POST" action="dos.php">
    <label>
        Usuario:
        <input type="text" name="user">
    </label>
    <br>
    <label>
    Contraseña:
    <input type="password" name="passwd">
    </label>
    <br>
    <button type="submit" name="enviar">Enviar</button>
</form>
</body>
</html>