<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<?php



$vivienda_actualizada = !empty($_POST['actualizar_viviendas']) ? $_POST['actualizar_viviendas'] : null;
$id_vivienda_actualizada = unserialize($vivienda_actualizada);
$vivienda = get_vivienda_por_id($id_vivienda_actualizada);

echo "\t\t<tr>\n";
echo "\t\t\t<td>" . $vivienda->getTipo() ."</td>\n";
echo "\t\t\t<td>" . $vivienda->getZona() ."</td>\n";
echo "\t\t\t<td>" . $vivienda->getNumeroDormitorios() ."</td>\n";
echo "\t\t\t<td>" . $vivienda->getPrecio() ."</td>\n";
echo "\t\t\t<td>" . $vivienda->getTamanio() ."</td>\n";
echo "\t\t\t<td>" . $vivienda->getExtras() ."</td>\n";
echo "\t\t\t<td>" . "<a href=\"" . $vivienda->getFoto() . "\"> <img src=\"/imagenes/ico-fichero.png\" title=\"imagen\" name=\"imagen\">" ."<a/></td>\n";
echo "\t\t<tr>\n";


$conexion = null;
$result = null;
$vivienda = null;
$lista = null;

// Nos conectamos a la base de datos
try {
    $opciones = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
    $conexion = new PDO("mysql:host=localhost;dbname=lindavista", "alumno", "velazquez", $opciones);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    $error = $e->getCode();
    die($error);
}

// Si se ha conectado bien
if ($conexion !== null) {
    // Realizamos la consulta
    try {
        // ACTUALIZACION
        $result = $conexion->query("");
    } catch (PDOException $e) {
        echo "Error de consulta: " . $e->getMessage();
    }

}

?>

</body>
</html>